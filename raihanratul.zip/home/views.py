from django.shortcuts import render
from .models import Responces

# Create your views here.
def home(request):
    if request.method == 'POST':
        name = request.POST.get("name")
        email = request.POST.get('email')
        subject = request.POST.get('subject')
        message = request.POST.get('message')
        responce = Responces.objects.create(name=name,email=email,subject=subject,message=message)
        responce.save()
    return render(request,'index.html')