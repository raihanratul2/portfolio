from django.db import models

# Create your models here.
 
 
class Responces(models.Model):
    name = models.CharField(max_length=40)
    email = models.CharField(max_length=40)
    subject = models.CharField(max_length=100)
    message = models.TextField()
    def __str__(self) -> str:
        return self.name